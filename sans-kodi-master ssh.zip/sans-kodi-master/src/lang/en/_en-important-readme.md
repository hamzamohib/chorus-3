## Warning: Files in this folder get overridden automatically

To edit the following files, you must do it in the original location and NOT in this folder. 
These files get get replaced regularly during a build or `grunt lang`.

### Where to edit these files:

* **app-readme.md** => /readme.md
* **app-changelog.md** => /changelog.txt
* **lang-readme.md** => /src/lang/readme.md

### Note

This only applies to english.
